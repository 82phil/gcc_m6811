/* Definitions of target machine for GNU compiler, for SPARC running Solaris 2
   using the GNU linker.  */

/* Undefine this so that attribute((init_priority)) works.  */
#undef CTORS_SECTION_ASM_OP
#undef DTORS_SECTION_ASM_OP
