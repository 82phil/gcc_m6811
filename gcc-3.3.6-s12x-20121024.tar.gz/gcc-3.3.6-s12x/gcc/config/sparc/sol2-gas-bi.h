/* Definitions of target machine for GNU compiler, for bi-arch SPARC
   running Solaris 2 using the GNU assembler.  */

#undef AS_SPARC64_FLAG
#define AS_SPARC64_FLAG	"-64 -Av9"
